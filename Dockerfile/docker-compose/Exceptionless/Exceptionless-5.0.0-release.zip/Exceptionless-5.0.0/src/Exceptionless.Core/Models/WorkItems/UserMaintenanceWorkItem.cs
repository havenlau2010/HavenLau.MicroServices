﻿using System;

namespace Exceptionless.Core.Models.WorkItems {
    public class UserMaintenanceWorkItem {
        public bool Normalize { get; set; }
    }
}