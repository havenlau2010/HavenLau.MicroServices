﻿using System;

namespace Exceptionless.Core.Models {
    public class PreviousAndNextEventIdResult {
        public string Previous { get; set; }
        public string Next { get; set; }
    }
}
