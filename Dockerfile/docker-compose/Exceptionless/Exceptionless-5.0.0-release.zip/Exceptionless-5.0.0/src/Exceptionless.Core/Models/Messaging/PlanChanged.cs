﻿using System;

namespace Exceptionless.Core.Messaging.Models {
    public class PlanChanged {
        public string OrganizationId { get; set; }
    }
}
