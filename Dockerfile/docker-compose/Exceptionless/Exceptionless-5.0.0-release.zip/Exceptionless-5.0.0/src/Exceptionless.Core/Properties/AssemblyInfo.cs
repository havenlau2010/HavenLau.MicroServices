using System;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Exceptionless.Tests")]
[assembly: InternalsVisibleTo("Exceptionless.Web")]
[assembly: InternalsVisibleTo("Exceptionless.Insulation")]
