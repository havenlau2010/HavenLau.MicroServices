﻿using System;

namespace Exceptionless.Web.Models {
    public class UpdateEvent {
        public string EmailAddress { get; set; }
        public string Description { get; set; }
    }
}
