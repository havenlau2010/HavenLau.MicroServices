﻿using System;

namespace Exceptionless.Web.Models {
    public class TokenResult {
        public string Token { get; set; }
    }
}