﻿using System;

namespace Exceptionless.Web.Models {
    public class UpdateToken {
        public string Notes { get; set; }
    }
}