﻿using System;

namespace Exceptionless.Web.Models {
    public class UpdateEmailAddressResult {
        public bool IsVerified { get; set; }
    }
}