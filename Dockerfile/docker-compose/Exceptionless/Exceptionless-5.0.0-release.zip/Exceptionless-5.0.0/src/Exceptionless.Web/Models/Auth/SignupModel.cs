using System;

namespace Exceptionless.Web.Models {
    public class SignupModel : LoginModel {
        public string Name { get; set; }
    }
}