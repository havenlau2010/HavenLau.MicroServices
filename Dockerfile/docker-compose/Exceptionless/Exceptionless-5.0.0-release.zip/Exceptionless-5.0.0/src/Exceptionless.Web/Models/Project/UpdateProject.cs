﻿using System;

namespace Exceptionless.Web.Models {
    public class UpdateProject {
        public string Name { get; set; }
        public bool DeleteBotDataEnabled { get; set; }
    }
}
