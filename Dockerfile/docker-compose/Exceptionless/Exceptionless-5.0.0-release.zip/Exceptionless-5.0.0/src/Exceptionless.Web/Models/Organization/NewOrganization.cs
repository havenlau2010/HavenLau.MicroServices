﻿using System;

namespace Exceptionless.Web.Models {
    public class NewOrganization {
        public string Name { get; set; }
    }
}