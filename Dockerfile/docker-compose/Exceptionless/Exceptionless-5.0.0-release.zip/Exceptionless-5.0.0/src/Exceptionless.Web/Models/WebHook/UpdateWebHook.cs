using System;

namespace Exceptionless.Web.Models {
    public class UpdateWebHook : NewWebHook {
        public bool IsEnabled { get; set; }
    }
}